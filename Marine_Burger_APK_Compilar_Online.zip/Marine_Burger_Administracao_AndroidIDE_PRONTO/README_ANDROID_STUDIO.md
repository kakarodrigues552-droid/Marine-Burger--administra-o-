# Marine Burger Administração — Android Studio

Projeto Android para o painel **Marine Burger Administração** com impressão **Bluetooth ESC/POS 80 mm**.

Abra no Android Studio a pasta que contém `settings.gradle` e `app/`.

## Gerar APK

No Android Studio:

`Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`

O APK de debug será criado em:

`app/build/outputs/apk/debug/app-debug.apk`

## Requisitos

- Android Studio atual
- JDK 17
- Android SDK 35
- Internet ativa para Supabase
- Impressora Bluetooth Classic/ESC-POS previamente pareada no Android

## Bluetooth

O app usa RFCOMM SPP e envia bytes ESC/POS diretamente para a impressora térmica de 80 mm.
