package com.marineburger.admin;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_BT = 7001;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private OutputStream output;
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adapter = BluetoothAdapter.getDefaultAdapter();
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new PrinterBridge(), "MarinePrinter");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
        requestBluetoothPermissions();
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQ_BT);
        }
    }

    private void connectInternal(String address) throws Exception {
        if (adapter == null) throw new Exception("Este aparelho não possui Bluetooth");
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) throw new Exception("Permissão Bluetooth não concedida");
        BluetoothDevice d = adapter.getRemoteDevice(address);
        if (socket != null && socket.isConnected()) return;
        if (adapter.isDiscovering()) adapter.cancelDiscovery();
        socket = d.createRfcommSocketToServiceRecord(SPP_UUID);
        socket.connect();
        output = socket.getOutputStream();
    }

    private void disconnectInternal() {
        try { if (output != null) output.close(); } catch(Exception ignored) {}
        try { if (socket != null) socket.close(); } catch(Exception ignored) {}
        output = null; socket = null;
    }

    public class PrinterBridge {
        @JavascriptInterface public boolean isAvailable() { return adapter != null; }
        @JavascriptInterface public String listPairedPrinters() {
            try {
                if (adapter == null) throw new Exception("Bluetooth indisponível");
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) throw new Exception("Permissão Bluetooth não concedida");
                JSONArray a = new JSONArray();
                for (BluetoothDevice d : adapter.getBondedDevices()) {
                    JSONObject x = new JSONObject(); x.put("name", d.getName()); x.put("address", d.getAddress()); a.put(x);
                }
                return a.toString();
            } catch(Exception e) { return "[]"; }
        }
        @JavascriptInterface public boolean connect(String address) {
            try { connectInternal(address); return true; } catch(Exception e) { return false; }
        }
        @JavascriptInterface public void disconnect() { disconnectInternal(); }
        @JavascriptInterface public boolean print(String base64) {
            try {
                if (output == null) throw new Exception("Impressora não conectada");
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                output.write(bytes); output.flush(); return true;
            } catch(Exception e) { return false; }
        }
    }

    @Override protected void onDestroy() { disconnectInternal(); if (web != null) web.destroy(); super.onDestroy(); }
}
