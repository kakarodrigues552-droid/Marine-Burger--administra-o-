# Marine Burger — Administração + Bluetooth ESC/POS 80 mm
## Projeto preparado para AndroidIDE

Este projeto instala o aplicativo de administração como um APK Android e usa uma ponte Java/WebView para impressão em impressora térmica Bluetooth 80 mm via ESC/POS.

### Ambiente
- AndroidIDE
- JDK 17
- Android Gradle Plugin 8.2.2
- Gradle 8.2.1
- compileSdk 34 / targetSdk 34

### Gerar APK
Abra a pasta raiz no AndroidIDE e faça o build de debug. O resultado esperado é `app/build/outputs/apk/debug/app-debug.apk`.

### Recursos
- Administração Marine Burger
- Supabase
- Pedidos em tempo real
- Cardápio por categoria/editor
- Bluetooth Classic RFCOMM SPP
- ESC/POS 80 mm
- Permissões Bluetooth Android 12+
